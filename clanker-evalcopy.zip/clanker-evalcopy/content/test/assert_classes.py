from abc import ABC, abstractmethod
from typing import Callable, Self

from core.engine_deps import IOControl
from core import RepoContract
from modules.tui import ActionResult
from core.engine_deps import UserDeclinedClankerize
from adapters.terminal.scripted_terminal_adapter import TestSequenceEnded
from base_classes import AssertSuite

class Sandbox(ABC):
    @abstractmethod
    def create_dirs(self, *paths: str) -> Self: ...

    @abstractmethod
    def create_file(self, path: str, content: str = "") -> Self: ...

    @abstractmethod
    def edit_file(self, path: str, old: str, new: str) -> Self:...

    @abstractmethod
    def rm(self, *paths: str) -> Self: ...

class Asserts(ABC):
    @abstractmethod
    def exit_msg_contains(self, expected_msg: str) -> Self: ...

    @abstractmethod
    def disk_manifest_has(self, expected_paths: list[str] | set[str]) -> Self: ...

    @abstractmethod
    def ui_render_contains(self, template: str) -> Self: ...

    @abstractmethod
    def prompt_render_contains(self, expected_prompt: str) -> Self: ...

    @abstractmethod
    def prompt_render_min_lines(self, count: int) -> Self: ...

    @abstractmethod
    def where(self, field: str, predicate: Callable[[str], bool]) -> Self: ...


class TestContainer(ABC):
    sequence: list[str]
    name: str
    preop: Sandbox
    expect: Asserts
    postop: Sandbox


class ActionsFactory(ABC):
    @abstractmethod
    def create_test(self, sequence: list[str], name: str = "") -> TestContainer: ...


class EmptyRepoTests(AssertSuite):
    TEMPLATE_FIXTURE_NAME = "empty_repo"

    def assert_end_of_sequence_terminates_properly(self, actions: ActionsFactory) -> list["TestContainer"]:
        return [
            actions.create_test([]) \
                .expect.exit_msg_contains(TestSequenceEnded.__name__)
        ]

    def assert_abort_keys_decline_init(self, actions: ActionsFactory) -> list["TestContainer"]:
        return [
            actions.create_test([key]) \
                .expect.exit_msg_contains(UserDeclinedClankerize.exit_msg)
            for key in IOControl.ABORT_KEYS
        ]

    def assert_clankerize_repo_contract(self, actions: ActionsFactory) -> list["TestContainer"]:
        return [
            actions.create_test(["yes", IOControl.ACCEPT_KEY]) \
                .expect.ui_render_contains(ActionResult.BOOTSTRAP_SUCCESS) \
                .expect.disk_manifest_has(RepoContract.get_all_target_paths()),
        ]

    def button_tree_exercise(self, actions: ActionsFactory) -> list["TestContainer"]:
        ats = []
        uno = ["1"]
        ats.append(
            actions.create_test(list(uno)) \
                .expect.ui_render_contains("Domain 'manifest-analysis' on key '1' selected")
        )
        for c in "as":
            ats.append(
                actions.create_test(list(uno + [c])) \
                    .expect.ui_render_contains(ActionResult.COPIED_TO_CLIPBOARD) \
                    .expect.where("lines", lambda l: int(l) > 100) \
                    .expect.where("chars", lambda c: int(c) > 3000) \
                    .expect.prompt_render_min_lines(50)
            )
        for c in "df":
            ats.append(
                actions.create_test(list(uno + [c])) \
                    .expect.ui_render_contains(ActionResult.UNBOUND_KEY) \
                    .expect.where("key", lambda k, target=c: str(k) == target)
            )
        return ats

class CorruptRepoTests(AssertSuite):
    TEMPLATE_FIXTURE_NAME = "empty_repo"

    def assert_clankerize_fail(self, actions: ActionsFactory) -> list["TestContainer"]:
        all_targets = list(RepoContract.get_all_target_paths())
        dir_targets = list(RepoContract.DIRS_TO_CREATE)
        file_targets = [dst for _, dst in RepoContract.MAPPINGS]

        items = [
            actions.create_test(["yes", IOControl.ACCEPT_KEY]) \
                .expect.ui_render_contains(ActionResult.BOOTSTRAP_SUCCESS) \
                .postop.rm(*all_targets)
        ]

        for dir in dir_targets:
            others = [t for t in dir_targets if t != dir]
            items.append(
                actions.create_test(["yes", IOControl.ACCEPT_KEY])
                    .preop.create_dirs(dir)
                    .expect.exit_msg_contains(others)
                    .postop.rm(dir)
            )

        for file in file_targets:
            others = [t for t in dir_targets if t != dir]
            items.append(
                actions.create_test(["yes", IOControl.ACCEPT_KEY]) \
                    .preop.create_file(file, content="contentosaurus rex") \
                    .expect.exit_msg_contains(others) \
                    .postop.rm(file)
            )
        return items